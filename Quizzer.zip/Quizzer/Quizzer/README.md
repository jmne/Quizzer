# Quizzer
> Quizduel nur für'n PC

## Installation

Windows & OS X & Linux:

```sh
Download and execute ツ
```

## Benutzung

Meldet euch an und spielt unser Quiz! Beantwortet möglichst viel richtig sonst gibts Haue..

Falls ihr noch Fragen habt schaut in unser [Wiki][wiki].


## Releases

* 0.0.1
    * Work in progress
    
* 0.1.0
    * Class structure/first features
    * SQl Connection
    * Project Site [Here](https://github.com/jancodet/Quizzer/projects/1)

* 0.2.0
    * GUI Start

* 0.2.1
    * New GUI Library
    * New Interface
    * Settings Menu