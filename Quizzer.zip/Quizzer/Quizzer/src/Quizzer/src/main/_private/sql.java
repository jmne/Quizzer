/*
 * Copyright (c) 2019 | Jan M. (@jncdt)
 */

package src.main._private;

public class sql {

    public static String d = "192.168.100.190";
    public static String b = "quizdatenbank_3";
    public static String u = "user11";
    public static String pw = "user11";
    public static int p = 3306;

}
