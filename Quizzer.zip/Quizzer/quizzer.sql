-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 22. Mrz 2019 um 00:35
-- Server-Version: 10.0.38-MariaDB-0+deb8u1
-- PHP-Version: 7.0.33-1~dotdeb+8.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `quizzer`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `benutzer`
--

CREATE TABLE `benutzer` (
  `Username` varchar(16) NOT NULL,
  `Email` varchar(32) DEFAULT NULL,
  `Passwort` varchar(32) NOT NULL,
  `BenutzerID` int(5) NOT NULL,
  `LastLogin` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `benutzer`
--

INSERT INTO `benutzer` (`Username`, `Email`, `Passwort`, `BenutzerID`, `LastLogin`) VALUES
('kevin.baier', NULL, '827ccb0eea8a706c4c34a16891f84e7b', 1, '2019-01-16 11:54:52'),
('pascal.nitsch', NULL, '827ccb0eea8a706c4c34a16891f84e7b', 2, '2019-01-16 11:57:07'),
('jan.menne', NULL, '827ccb0eea8a706c4c34a16891f84e7b', 3, '2019-01-16 11:58:13'),
('jan.krug', NULL, '827ccb0eea8a706c4c34a16891f84e7b', 4, '2019-01-16 11:57:53'),
('1', '', 'c4ca4238a0b923820dcc509a6f75849b', 5, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `fragen`
--

CREATE TABLE `fragen` (
  `FrageID` int(5) NOT NULL,
  `Frage` varchar(250) NOT NULL,
  `Kategorie` int(32) NOT NULL DEFAULT '1',
  `A1` varchar(128) NOT NULL,
  `A2` varchar(128) NOT NULL,
  `A3` varchar(128) NOT NULL,
  `A4` varchar(128) NOT NULL,
  `KorrekteAntwort` varchar(1) NOT NULL,
  `Bearbeitet` int(255) NOT NULL,
  `Richtig` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `fragen`
--

INSERT INTO `fragen` (`FrageID`, `Frage`, `Kategorie`, `A1`, `A2`, `A3`, `A4`, `KorrekteAntwort`, `Bearbeitet`, `Richtig`) VALUES
(1, 'Wann starb Steve Jobs?', 1, '2010', '2011', '2012', '2013', '2', 0, 0),
(2, 'Wie viel Liter sind ein Barrel?', 1, '100', '127', '159', '183', '3', 3, 0),
(3, 'Mit welchem Gas flog der erste Zeppelin?', 4, 'Helium', 'Methan', 'Argon', 'Wasserstoff', '4', 1, 1),
(4, 'Aus wie vielen Diamanten wird ein Diamantschwert gecraftet?', 1, '7', '2', '3', '4', '2', 1, 1),
(5, 'Wie schwer ist eine Unze?', 2, '28,6495 Gramm', '28,1495 Gramm', '28,3495 Gramm', '28,2495 Gramm', '3', 2, 0),
(6, 'Wer hat Google gegründet?', 4, 'Steve Jobs & Bill Gates', 'Larry Page & Sergey Brin', 'Michael Bay & Arnold Schwarzenegger', 'Elon Musk & Kim Jong Un', '2', 1, 0),
(8, 'Wie heißt Bushido mit Vornamen?', 1, 'Anis', 'Michael', 'Patrick', 'Mohammed', '1', 0, 0),
(7, 'Wie weit ist Voyager 1 ca. von der Erde entfernt?(14.1.19)', 2, '99,61 Millionen Kilometer', '587,42 Millionen Kilometer', '10,78 Milliarden Kilometer', '21,60 Milliarden Kilometer', '4', 0, 0),
(9, 'Wie viele Spieler spielen aktiv Fortnite?', 6, '100 Millionen', '150 Millionen', '200 Millionen', '175 Millionen', '3', 1, 0),
(10, '„Uh oh, uh oh, uh oh, oh, no, no. Uh oh, uh oh, uh oh, oh, no, no. Uh oh, uh oh, uh oh, oh, no, no. Uh oh, uh oh, uh oh, oh, no,', 1, 'Beyoncé in „Crazy In Love“', 'Madonna in „Music“ ', 'Lady Gaga in „Paparazzi“ ', 'Lena in „Satellite“ ', '1', 0, 0),
(13, 'Wie heißt Batman mit bürgerlichem Namen?', 1, 'Tony Stark', 'Michael Bay', 'Bruce Wayne', 'Bill Gates', '3', 0, 0),
(14, 'Wie lange dauert es ein Straußenei hart zu kochen?', 1, '10 min', '20 min', '30 min', '40 min', '4', 1, 0),
(11, 'Wie heißt der Autor von Jim Knopf?', 1, 'Astrid Lindgren', 'Michael Ende', 'Shindy', 'Peter Müller', '2', 0, 0),
(12, 'Was verbindet das Auge mit dem Gehirn?', 2, 'Kabel', 'Sehnerv', 'Bluetooth', '4G', '2', 0, 0),
(15, 'Wie viel darf ein Boxer der Fliegengewichtsklasse maximal wiegen?', 1, '46', '48', '51', '54', '3', 0, 0),
(17, 'Wie lange dauerte die Apollo 11 Mission?', 2, '23h 33min 15sek', '3d 15min 45sek', '6d 55min 25sek', '8d 3h 18min 35s ', '4', 2, 1),
(16, 'Wie viel Umsatz hat Apple im Jahr 2018 erwirtschaftet (in Milliarden US-Dollar)?', 1, '109,2', '177,9', '265,6', '187,4', '3', 0, 0),
(18, 'Wie viel war ein US$ November 1923 in Deutschland wert?', 4, '1.489 Mark', '0.776 Mark', '2.432 Mark', '4 Billionen Mark', '4', 0, 0),
(19, 'Wie viele Nebelpartikel müsste man sammeln um einen Teelöffel voll zu haben?', 2, '7 Miliarden', '698.655', '98,5 Millionen', '11 Trillionen', '1', 1, 0),
(20, 'Wie viele Räume hat der Buckingham Palace?', 6, '598', '615', '602', '623', '3', 0, 0),
(26, 'Wie viel Prozent der im menschlichen Körper befindlichen Atome werden innerhalb eines Jahres ersetzt?', 2, '100%', '37%', '98%', '78%', '3', 0, 0),
(27, 'Wie lange dauert es ein Straußenei hart zu kochen?', 2, '30min', '40min', '1std', '5std', '2', 0, 0),
(28, 'Wie viele Fotos wurden Silvester 2011/2012 auf Facebook hochgeladen?', 1, '750mio', '500mio', '1mrd ', '250mio', '1', 0, 0),
(29, 'Aus welchem Land kam der größte jemals gemessene Mensch?', 4, 'Savietunion', 'Australien', 'Kongo', 'USA', '4', 0, 0),
(30, 'Aus wieviel Knochen besteht die menschliche Hand?', 1, '24', '26', '27', '31', '3', 0, 0),
(25, 'Welche Geschwindigkeit haben Nervenimpulse im Menschen?', 2, '95m/s', '110m/s', '120m/s', '140m/s', '3', 0, 0),
(24, 'Wann wurde das iPhone 4 veröffentlicht?', 7, '2010', '2011', '2012', '2009', '1', 0, 0),
(23, 'Wie lange braucht Schall um 1km zurückzulegen?', 2, '1sek', '2sek', '2.5sek', '3sek', '4', 0, 0),
(22, 'Wie viele Stellen hat ein Strichcode der Europäischen Artikelnummer?', 1, '26', '22', '45', '13', '4', 3, 0),
(21, 'Wann kam die CD raus?', 4, '1978', '1982 ', '1986', '1990', '2', 1, 1),
(36, 'Wie oft wird der deutsche Aktienindex pro Stunde errechnet?', 1, '60 Mal', '120 Mal ', '12 Mal', '3600 Mal', '4', 0, 0),
(37, 'Wie alt wurde der erste deutsche Bundeskanzler der Bundesrepublik Deutschland?', 4, '87', '54', '81', '91', '4', 0, 0),
(38, 'Wie lang ist ein Tennisfeld?', 1, '23.77m', '25m', '25.35m', '27.8m', '1', 0, 0),
(39, 'Wie lange muss ein Mensch durchgehend schreien, um mit der produzierten Energie eine Tasse Kaffee erhitzen zu können?', 6, '3,7std', '8 1/2 Jahre', '56 Jahre', '40 Jahrzehnte', '2', 0, 0),
(40, 'Wieviele Teile Besteck gibt es im Weißen Haus ?', 6, '13.092', '5.698', '1.242', '8.214', '1', 0, 0),
(41, '  Wieviele Studenten sind zur Zeit an der größten Universität der Welt in Indien eingeschrieben ?  Inklusive Fernstudium !', 6, '587.633', '1.68mio', '2.36mio', '8.6mio', '3', 0, 0),
(42, 'Wieviele Abbonenten hat der Youtube-Channel der Bundesregierung ?', 3, '236.889', '98', '5.224', '26.985', '3', 0, 0),
(43, 'Wieviel Prozent der Weltbevölkerung hat noch nie einen Telefonanruf erhalten oder getätigt ?', 6, '1%', '53%', '5%', '68%', '2', 0, 0),
(44, 'Wieviel Prozent aller weltweiten Schäden an Kopieren werden dadurch verursacht, dass Menschen ihren Arsch fotokopieren ?', 6, '12%', '76%', '30%', '23%', '4', 0, 0),
(45, 'Wann hat Obama zum ersten Mal gekackt?', 3, 'mit 44 Jahren', 'nach 1 min', 'noch nie', 'zur Hochzeit', '3', 0, 0),
(46, 'In welchem Jahr fand die Markteinführung der Playmobilfiguren statt?', 4, '1972', '1973', '1974', '1978', '3', 0, 0),
(47, 'In welchem Jahr startete in Deutschland \"Wer wird Millionär\"?', 4, '1988', '1999', '2000', '1977', '2', 0, 0),
(48, 'Wie schwer ist eine Giraffe ungefähr?', 6, '600kg', '700kg', '800kg', '900kg', '3', 1, 0),
(49, 'Wie groß ist das Gesamtvolumen des Bluts eines Blauwals?', 6, '6000-6500 Liter', '7000-7500 Liter', '3000-3500 Liter ', '12 Liter', '2', 1, 0),
(50, 'Wann war der offizielle release von Wasserpfeifenblues? (by LilKelv)', 1, '4.5.18', '28.12.18', '15.11.18', '23.10.18', '3', 0, 0),
(51, 'Im Vatikanstaat darf man Sex mit Kindern ab ... Jahren haben.', 1, '12', '14', '16 ', '18', '1', 0, 0),
(52, 'Wie schwer kann der Horst eines Weißkopfseeadlers werden?', 1, '40kg', '85kg', '253kg', '450kg', '4', 0, 0),
(53, 'Wie viel Prozent der Zuschauer von Spongebob sind Erwachsene ohne Kinder?', 6, '9%', '16%', '25%', '60%', '3', 0, 0),
(64, 'In welchem Jahr wurde Lucky Luke zum Nichtraucher? Der belgische Comic erschien erstmals im Jahr 1946', 4, '1969', '1982', '1999', '1975', '2', 1, 0),
(58, 'Wie viel Milliliter sind ein Liter?', 2, '55', '1000', '3', '758', '2', 1, 0),
(56, 'Wie viel wiegt GZUZ?', 1, '14kg', '85kg', '100kg', '112kg', '3', 0, 0),
(57, 'Wer hat den Keks aus der Dose geklaut?', 3, 'Kevin', 'Pascal', 'Konstantin', 'Frau Rühl', '1', 2, 1),
(54, 'Wer gat das Spiel 77 erfunden?', 1, 'Arnes Kotullu', 'Hanns-Josef Christ', 'Manny-Jobst Grünhauser', 'Al\' Chak Tuhrr\' 77', '2', 0, 0),
(61, 'Was ist  das Motto von Team 3?', 3, 'Bros before Hoes', 'Masse statt Klasse', 'Qualität statt Quantität', 'Kein Bier vor 4', '2', 0, 0),
(55, 'Wie schwer ist der Mond?', 2, '7,347 · 1022 kg ', '15 kg', 'Nichts, da er schwebt ', '7,349 · 1022 kg ', '4', 1, 0),
(59, 'In welchem Jahr gab es den ersten selbst gebastelten Adventskalender?', 4, '1695', '1777', '1546', '1851', '4', 0, 0),
(65, 'Wie viele Entenarten gibt es auf der Welt?', 6, '150', '200', '100', '250', '1', 0, 0),
(60, 'Was ist die Rotationsperiode des Uranus?', 2, '15 h 34 min 26 s ', '12 h 51 min 54 s ', '17 h 14 min 24 s ', '18 h 44 min 02 s ', '3', 0, 0),
(66, 'Wie viel Liter Kunstblut gingen für beide Teile des Kultfilms \"Kill Bill\" drauf?', 6, '1020', '1608', '1700', '1850', '3', 0, 0),
(67, 'Wie viele Tage verbringt ein Deutscher in seinem Leben durchschnittlich auf dem Klo?', 6, '50', '130', '150', '230', '4', 0, 0),
(68, 'Wie viele Zähne hat ein Eisbär?', 6, '42', '44', '39', '41', '1', 0, 0),
(62, 'Wie viele Länder gibt es in Afrika?', 1, '55', '39', '64', '81', '1', 1, 0),
(63, ' Wie viele Sprachen werden auf der Welt gesprochen?', 1, '200', '300', '6500', '400', '3', 0, 0),
(69, 'Bis zu welchem Jahr musste bei Geburten im britischen Königshaus der Innenminister dabei sein?', 4, '1945', '1948', '1845', '1848', '2', 1, 1),
(70, 'Wie oft schauen wir pro Tag durchschnittlich auf das Handy?', 6, '66', '77', '88', '99', '3', 0, 0),
(71, 'Wie lange halten Ehen im Schnitt?', 6, '1 Jahr', '5 Jahre', '10 Jahre', '15 Jahre', '4', 0, 0),
(72, 'Wie groß waren die  Wirbel des Argentinosaurus?', 2, '1,59 Meter', '5,12 Meter', '4,55 Meter', '5,38 Meter', '1', 0, 0),
(73, 'Welche Atommasse hat Sauerstoff?', 1, '0,847 u', '15,999 u', '55,214 u', '5,740 u', '2', 0, 0),
(74, 'Wann war der letzte Polsprung?', 2, 'vor 540 000 Jahren', 'vor 1,2mio Jahren ', 'vor 780 000 Jahren ', 'vor 960 000 Jahren', '3', 0, 0),
(75, 'Wie weit ist die Andromeda Galaxie entfernt?', 1, '1mio Lichtjahre', '1.5mio Lichtjahre', '2mio Lichtjahre', '2.5mio Lichtjahre', '4', 0, 0),
(76, 'Wie alt ist das älteste Tier der Welt?', 2, '284 Jahre', '507 Jahre  ', '674 Jahre', '10000 Jahre', '4', 1, 0),
(77, 'Wie groß ist der download von \"Java Windows Offline (64-Bit)\" Stand 1.2.19', 7, '71.44 MB ', '55.44 MB ', '84.44 MB ', '78.44 MB ', '1', 0, 0),
(31, 'Wieweit ist die Galaxie GN-z11 entfernt?', 2, '9,4 mrd Lichtjahre ', '13,4 mrd Lichjahre', '16,4 mrd Lichtjahre', '8,4 mrd Lichtjahre', '2', 0, 0),
(32, 'Wie viel wiegt LX exakt ab?', 7, '500 gramm', '1000 gramm', '400 gramm', '800 gramm', '2', 1, 0),
(33, 'Wann ist Stephen Hillenburg(der Erfinder von SpongeBob) gestorben?', 1, '16. September 2018', '26. November 2018', '11. September 2018', '24. Dezember 2018', '2', 1, 0),
(34, 'Wie viele Strophen hat die griechische Nationalhymmne?', 6, '189', '163', '158', '132', '3', 0, 0),
(35, 'Wie viele Buchstaben hat das Hawaiianische Alphabet?', 6, '10', '12', '14', '16', '2', 1, 0),
(78, 'Seit wann herrscht in Deutschland die Gurtpflicht für PKW auch auf dem Rücksitz?', 4, '1.12.1953', '4.6.1977', '1.8.1984', 'Es gibt keine Gurtpflicht', '3', 0, 0),
(79, 'Wie lange ist die durchschnittliche Tragzeit einer Renozeroskuh?', 6, '300 Tage', '400 Tage ', '500 Tage', '600 Tage', '3', 0, 0),
(80, 'Wie lautet die Vorwahl der Antarktis?', 1, '+627', '+425', '+199', '+001', '1', 0, 0),
(81, 'Wie lange kaut ein europäer durchschnittlich am Tag?', 6, '1std', '30min', '1std30min', '50min', '2', 2, 1),
(82, 'Wie viel Kalorien haben 100g Rotlachs?', 1, '138', '201', '169', '184', '3', 0, 0),
(83, 'Auf wie viele verschiedene Weisen können 10 CDs auf einem Regal arrangiert werden`?', 6, '328.800', '30.800', '30.628.800', '3.628.800', '4', 0, 0),
(84, 'Wie viel kosten Apple AirPods?(Direkt von Apple)', 7, '180,00 €', '169,99 €', '159,95 €', '16,800 Yen', '4', 0, 0),
(85, 'Wovor hat man Angst wenn man an Cherophobie leidet?', 2, 'Kindern', 'Spaß', 'Clowns', 'Sex', '2', 1, 0),
(86, 'Wie nennt man Babyspinnen?', 1, 'Spindlings', 'Spiderlinge', 'Spidis', 'Spinling', '2', 1, 0),
(87, 'Wann wurde der erste Bitcoin erschaffen?', 7, '5. April 1999', '18. Semptember 2012', '3. Januar 2009', '7. August 2004', '3', 1, 0),
(88, 'Wie viel ist 1 Iranischer Rial wert?', 6, '0,00026 Euro', '0,0000091 Kuwait-Dinar', '0,000003 US-Dollar', '4,02 Indonesische Rupiah', '2', 1, 0),
(89, 'Wie viel Prozent des Eises der Antarktis besteht aus Pinguinurin?', 2, '1%', '3%', '6%', '10%', '2', 1, 0),
(90, 'Wie heißt der Twittervogel?', 1, 'Parry', 'Berry', 'Larry', 'Kelvin', '3', 0, 0),
(91, 'Wie alt ist der YouTuber MontanaBlack88?', 1, '23', '30', '26', '20', '2', 0, 0),
(92, 'Wo findet die Weltmeisterschaften im Schneckenrennen statt?', 6, 'Congham (England)', 'Freshford (Irland)', 'Rahula (Finnland)', 'Bueng (Thailand)', '1', 0, 0),
(93, 'Die wievielste Sekunde erlebt man wenn man 31,7 Jahre alt ist?', 6, 'Die Billionste', 'Die Billiardste', 'Die Millionste', 'Die Milliardste', '4', 1, 0),
(94, 'Wie weit schreibt ein Kuglschreiber durchschnittlich?', 6, '500m', '20km', '2,5km', '10km', '3', 1, 0),
(95, 'Wie lang ist die längste Zunge?', 6, '10cm', '12cm', '14cm', '16cm', '1', 0, 0),
(96, 'Welches Unternehmen ist der größte Uhrenhersteller der Welt?', 7, 'Rolex', 'Breitling', 'Omega', 'Apple', '4', 0, 0),
(97, 'Wie viele Menschen stecken sich in Deutschland durchschnittlich mit AIDS an?', 1, '3000', '30.000', '300.000', '300', '1', 0, 0),
(98, 'Wann erreichte Fortnite $1 Milliarde Gewinn durch Ingame-Käufe', 1, '18.07.2018', '11.02.2019', '11.09.2018', '22.12.2018', '1', 0, 0),
(99, 'Wie viel verdient der Macher von Candy Crush pro Tag?', 6, '488k', '985k', '633k', '577k', '3', 0, 0),
(100, 'Wie viele Galaxien verdeckt ein Sandkorn wenn man es in den Himmel hält?', 2, '10', '10.000', '100.000', '100.000.000.000.000.000.000', '2', 1, 0),
(101, 'Umfang der Erde?', 2, '38.075 km', '27.245 km', '40.075 km', '43.847 km', '3', 0, 0),
(102, 'Wie viel Sonnenradien hat KY Cygni ungefähr?', 6, '8420', '2850', '430', '15470', '2', 1, 1),
(103, 'Was heißt Urgroßmutter auf Schwedisch?', 6, 'Muffmater', 'Rochmudmud', 'Gammelmormor', 'Krabbmata', '3', 0, 0),
(104, 'Wie hoch ist der materielle Wert einer 500 Euro Banknote?', 2, '16 Euro', '16 Cent', '1.6 Euro', '3.4 Euro', '2', 0, 0),
(105, 'Wie viel kcal verbraucht ein Orang-Utan durchschnittlich?', 6, '1600', '2500', '800', '1100', '1', 1, 0),
(106, 'Was heißt \"Grünkohl\" auf Bosnisch?', 6, 'jagoda', 'kelj', 'guthi', 'nulke', '2', 0, 0),
(107, 'In welchem Jahr war Kevin der beliebteste Vorname?', 4, '1991', '1995', '1999', '2002', '1', 0, 0),
(108, 'Welche Hausnummer hatte die Firma „Farina“ in der Glockengasse in Köln?', 6, '4711', '6969', '9111', '1234', '1', 0, 0),
(109, 'Wie viele Zeichen darf eine Domain haben?', 7, '49', '56', '63', '72', '3', 1, 0),
(110, 'Wie alt ist unser Trinkwasser?', 2, 'drei Milliarden Jahre', 'zweieinhalb Milliarden Jahre', '500 Jahre', '12 Tage', '1', 0, 0),
(111, 'Wie viel Staaten haben Linksverkehr?', 3, '48', '69', '2', '59', '4', 0, 0),
(112, 'Wie schnell ist die schnellste Internetleitung? (2018)', 2, '1,6 Terabits', '2,6 Terabits', '5,6 Terabits', '3,6 Terabytes', '1', 0, 0),
(113, 'Wie groß soll die BFR von SpaceX werden?', 2, '109m', '351m', '384m', '471m', '1', 0, 0),
(114, 'Wie groß war der Schädel des Herrerasaurus?', 2, '247cm', '475cm', '56cm', '107cm', '3', 11111112, 11),
(115, 'Ein MAN TGS wiegt ungefähr so viel wie?', 2, '0.0000000000000000000021777 Monde', '85555 3-lagiges Toilettenpapier', '303000 BIC J26 Feuerzeuge', '42947 Iphone Xs', '1', 2, 0),
(116, 'Als was wurden Wasserschweine einst von der katholischen Kirche eingestuft?', 1, 'Schweine', 'Fische ', 'Ratten', 'Rind', '2', 0, 0),
(117, 'Wofür steht das \"ZIP\" in ZIP Code?', 1, 'Zentral Investigation Programm', 'Zero Impact Patrol', 'Zone Improvement Plan', 'Zed Interrogation Pact', '3', 0, 0),
(118, 'Wie oft hat Elvis eine Zugabe gegeben?', 1, '14 Mal', '18 Mal', '36 Mal', '0 Mal :(', '4', 0, 0),
(119, ' Was gab die Sovietunion 1989 Dem Pepsi Konzern damit dieser weiter Pepsi bei Ihnen Pepsi verkauft?', 4, '23 Mio Dollar', '4 Ölbohrinseln und 7 Kampfjets', 'Zugehörigkeit zur Sovietunion und damit Schutz und Geld', '17 U-Boote, 1 Kreuzer, 1 Fregatte und 1 Zerstörer', '4', 1, 0),
(120, 'Wie hieß der erste Zivilist, der einen Militärgeländewagen vom Typ \"Hummer\" besaß?', 1, 'Donald Trump', 'Arnold Schwarzenegger', 'Rambo', 'Dwayne Johnson', '2', 0, 0),
(121, 'Welches Organ haben Schnabeltiere nicht?', 1, 'Magen', 'Niere', 'Milz', 'Leber', '1', 0, 0),
(122, 'Welche Form hat Wombatkacke?', 1, 'Kugel', 'Pyramiede', 'Würfel', 'Zylinder', '3', 0, 0),
(123, 'Wie oft passt die Erde in Uranus?', 1, '3 Mal', '63 Mal', '663 Mal', '6663 Mal', '2', 1, 0),
(124, 'Wie viel Bäume gibt es etwa auf der Erde?', 6, '1Million', '1Milliarden', '1Billion', '1Billiarden', '3', 1, 0),
(125, 'Wie viel Prozent der Landesfläche Schwedens sind mit Heidelbeerensträuchern bedeckt?', 6, '~12%', '~15%', '~17%', '~1%', '3', 0, 0),
(126, 'Wie viele Rillen befinden sich auf dem Rand eines viertel Dollars?', 1, '111', '119', '222', '229', '2', 0, 0),
(127, 'Wie heißt die Abkürzung der Gewerktschaft deutscher Flugbegleiter?', 1, 'GdF', 'NASA', 'UFO', 'SPACE', '3', 0, 0),
(128, 'Wie viel Prozent der Weltbevölkerung hat roote Haare?', 1, '1%', '5%', '3%', '7%', '2', 0, 0),
(129, 'Wie viel kostet 1g Gras in den Apotheken von Uruguay?', 1, '1$', '5$', '10$', '15$', '1', 1, 0),
(130, 'Wie hieß der Planet Uranus von 1781-1850?', 4, 'Leroy', 'Gregory', 'George ', 'Clevelant', '3', 0, 0),
(131, 'Wie viel Prozent der Gras Konsumenten ist abhängig?', 6, '9%', '19%', '29%', '39%', '1', 0, 0),
(132, 'Wie viel Prozent des Datenverkehrs im Internet sind Pornographischen ursprungs?', 6, '9%', '23%', '35%', '48%', '3', 11, 1),
(133, 'Wie groß ist das Risiko sich auf der Toilette zu verletzen?', 6, '1:100', '1:1.000', '1:10.000', '1:100.000', '3', 1, 0),
(134, 'Wer hat das toilettenpapier erfunden?', 4, 'Die Deutschen', 'Die Mongolen', 'Die Mexikaner', 'Die Chinesen', '4', 1, 0),
(135, 'Wie viel wiegt Deutschland? (von der 20-40km dicken Erdkruste aus gemessen)', 1, '28 Billiarden Tonnen', '28 Trillionen Tonne', '28 Quintillionen Tonnen', '28 Unvigintillionen Tonnen', '1', 0, 0),
(136, 'Wie viel Prozent der Kinder unter 8 Jahren in Deutschland können nicht schwimmen?', 1, '~10', '~20', '~30', '~40', '4', 1, 1),
(137, 'Wie heißt eine Stadt in Südafrika?', 1, 'Wixburg', 'Ficksburg', 'Fotzburg', 'Poperzburg', '2', 11113, 11),
(138, 'Wie viele Fehrnsehkanäle empfängt ein durchschnittlicher US-Haushalt?', 1, '200', '300', '400', '500', '3', 0, 0),
(139, 'Wie viel wiegt eine menschliche Träne durchschnittlich?', 1, '1,5g', '0.15g', '0.015g', '0.0015g', '3', 0, 0),
(140, 'Wie viel Prozent der Gefangenen in Deutschland sind Frauen?', 1, '5%', '10%', '15%', '20%', '1', 0, 0),
(141, 'Wie viel Liter Tränen weint ein Mensch in seinem Leben?', 1, '5 L', '2L', '8L', '80L', '4', 0, 0),
(142, 'Wie viel wiegt eine Portion Zuckerwatte etwa?', 1, '1g', '5g', '6g', '7g', '3', 0, 0),
(143, 'Wie viel Prozent der deutschen werden nach dem Tod verbrannt?', 1, '3%', '48%', '72%', '99%', '2', 0, 0),
(144, 'Welche technische Neuheit ließ die Evangelische Kirche Berlin 2018 patentieren?', 1, ' Hologramm-Pastor', 'Klingelbeutel mit Kartenlesegerät', 'Kirchenbänke mit integrierten Gesangsdisplays', 'Biblen mit USB-Port', '2', 0, 0),
(145, 'Dürfen im Internet gekaufte Blumen innerhalb von 14 Tagen wieder zurückgegeben werden?', 1, 'Ja, das 14-tägige-Rückgaberecht gilt für alle Online-Artikel.', 'Nur Blumen im Topf können zurückgegeben werden.', 'Nein, denn Blumen sind generell schnell verderblich', 'Nur wenn sie nicht verwelkt sind.', '2', 0, 0),
(146, 'Wer unter einer Katzenhaarallergie leidet, ...?', 1, ' sollte vor allem langhaarige Katzen meiden', 'ist vermehrt im Herbst betroffen', 'ist hauptsächlich gegen den Speichel der Tiere allergisch', 'hat niemals auch eine Hundehaaralergie', '3', 2, 1),
(147, 'Womit kann eine Grundreinigung der Waschmaschine durchgeführt werden?', 1, ' Glasreiniger', 'Haarspülung', 'Geschirrspültabs', 'Frostschutzmittel', '3', 0, 0),
(148, 'Auf der Raumstation ISS ...?', 1, ' kommt alle drei Monate die Müllabfuhr', 'ertönt jeden Morgen um sechs Uhr Hahnenkrähen', 'muss mindestens ein Bewohner eine Friseurausbildung haben', 'muss man Stoppersocken tragen', '1', 0, 0),
(149, 'Wer wendet den sogenannten Pummeltest an? ', 1, 'Glaser beim Testen von Verbundsicherheitsglas', 'Diätassistenten beim Messen des Muskel-Fett-Verhältnisses', 'Imker bei der Auswahl der richtigen Bäume zum Bestäuben', 'Mechaniker beim Spur einstellen', '1', 2, 2),
(150, 'Wer einem Trend am Hofe Ludwig XIV. folgen wollte, ...?', 1, 'verspeiste ein paar junge, rohe Erbsen', 'lernte Bulgarisch als Zweitsprache', 'beherrschte die Conga-Trommel', 'übte sich im Schachspielen', '1', 0, 0),
(151, 'Warum sorgt der in Hautcremes enthaltene Stoff Urea für eine glattere Hautoberfläche?', 1, 'Er füllt Fältchen auf.', 'Er saugt Feuchtigkeit aus tieferen Hautschichten an die Oberfläche.', 'Er baut die Verbindungen zwischen abgestorbenen Hautzellen ab.', 'Er zieht die Haut zusammen', '3', 1, 0),
(152, 'Wissenschaftler stellten fest, dass so gut wie jeder Tropfen Wasser, den wir konsumieren, ...?', 1, ' seinen Ursprung im Nord- und Südpol hat', 'durch den Körper eines Dinosauriers gewandert ist', 'schon einmal mit dem Erdkern in Berührung gekommen ist', 'einem Asiaten bereits zum Reiskochen diente.', '2', 1, 0),
(153, 'Vulcan Point auf den Philippinen ist eine Insel in einem See, ...?', 1, 'der nur zweimal am Tag für 30 Minuten Wasser führt', 'der aus flüssiger, kalter Lava besteht', 'der auf einer Insel in einem See auf einer Insel im Meer liegt', 'der Pink erscheint', '3', 1, 0),
(154, 'Weshalb sind die Zähne eines Sägeblattes abwechselnd leicht nach links und rechts gebogen?', 1, 'weil das Blatt sonst zu stark schwingen würde', 'um zu verhindern, dass das Blatt schief schneidet', 'damit das Blatt nicht während des Sägens steckenbleibt', 'Damit der abrieb vermindert wird.', '3', 1, 0),
(155, 'Was gilt es, bei der Kühlschranklagerung von frischen Kräutern wie Petersilie oder Dill zu beachten?', 1, 'Es sollten vorher die Stielenden abgeschnitten werden.', 'Sie sollten nicht im Gemüsefach gelagert werden.', 'Mediterrane Kräuter sollten nicht mit einheimischen gelagert werden.', 'Sie müssen bei 2 Grad oder Kälter gelagert werden.', '1', 0, 0),
(156, 'Welches dieser Verkehrsvergehen zieht das geringste Bußgeld nach sich?', 1, 'Einbahnstraße in falscher Richtung befahren', 'Beim Fahrradfahren das Handy nutzen', 'Bei Glatteis oder Schnee ohne Winterreifen fahren', 'Links überholen', '1', 1, 0),
(157, 'Mit welchem Problem sahen sich Mitarbeiter des Wildlife Rehabilitation Center in Wisconsin im Sommer 2018 konfrontiert?', 1, ' Bärenpaar auf Spritztour in einem Golfcart', 'Eule mit einer Mäusephobie', 'Fünf an den Schwänzen verknotete Grauhörnchen-Babys', 'Rabenangriff auf einen Kiosk', '3', 1, 0),
(158, 'Wer seine Katze während des Urlaubs durch einen Tier-Sitter in den eigenen vier Wänden betreuen lässt, ...?', 1, 'muss einen Erste-Hilfe-Kasten bereitstehen haben', 'muss die Tätigkeit beim Tierschutzbund anmelden', 'darf keine Mäuse haben', 'kann die Kosten von der Steuer absetzen', '4', 0, 0),
(159, 'Auf welchen Trick schwören Vielflieger, um am Zielort die Wartezeit am Gepäckband wesentlich zu verkürzen?', 1, 'so früh wie möglich vor dem Abflug einchecken', 'beim Check-in um einen „Zerbrechlich“-Aufkleber fürs Gepäck bitten ', 'den aufgegebenen Koffer mehrfach in Frischhaltefolie einwickeln', 'den Koffer mit Kaffee einreiben', '2', 0, 0),
(160, 'Welcher dieser Sätze enthält einen distributiven Singular?', 1, 'In der Mittagssonne bekamen viele Besucher eine rote Nase.', 'Den meisten ist es egal, ob das Spiel hier oder dort stattfindet.', 'Frau Rühl und Kevin wissen beide nicht die richtige Antwort.', 'Konstantin mag das Gelächter des langen Kelvins', '1', 0, 0),
(161, 'Warum strecken viele Kinder die Zungenspitze heraus, wenn sie sich auf eine händische Aufgabe konzentrieren?', 1, 'weil Gesten eine frühe Form der Sprache sind', 'weil das Gehirn dadurch besser durchblutet wird', 'weil unsere Vorfahren über die Zunge ihre Temperatur regelten', 'Asperger', '1', 0, 0),
(162, 'Womit können Setzlinge unbeschadet Frost überstehen?', 1, 'halbierter Schuhkarton', 'Kreuzschraubenzieher ', 'abgeschnittene Plastikflasche', 'Pringels Dose', '3', 0, 0),
(163, 'Wobei kann Rote-Bete-Saft helfen?', 1, 'Haarwuchs stärken', 'Blutdruck senken', 'Lederschuhe pflegen', 'Spinatflecken entfernen', '2', 0, 0),
(164, 'Was könnte nach neuesten Forschungen künftig die Genauigkeit seismischer Messungen revolutionieren? ', 1, 'abschmelzende Gletscher', 'Schrittzähler-Apps für Smartphones', 'unterirdische Glasfasernetze', 'Ölbohrplattformen', '3', 0, 0),
(165, 'Was ließ sich der US-Amerikaner Virgil Gates im Jahr 1876 patentieren?', 1, 'Schutzschild für den Schnurrbart', 'portabler Taschenrechner für das kleine Einmaleins', 'Schreibmaschine, die sein Enkel Bill weiterentwickelte', 'Einen Blitzableiterhut', '1', 1, 0),
(166, 'Warum fressen Flohkäfer Löcher in Blätter?', 1, 'Sie befreien die Pflanze von Blattläusen.', 'Sie belüften ihre Schlafplätze unterhalb des Blattes. ', 'Sie tarnen sich.', 'Sie haben Hunger', '3', 2, 1),
(167, 'Mary, Alice und Victoria waren ...?', 1, ' 2009 die ersten Wellensittiche im Weltall', 'im April 2018 für wettbegeisterte Briten Grund zur Enttäuschung', ' 2017 die beliebtesten nicht-asiatischen Vornamen in Südkorea ', 'im Dezember 2015 Kinder die in einen Vulkan gefallen sind', '2', 0, 0),
(168, 'Welche dieser weiblichen Popgrößen wurde zuerst geboren?', 1, 'Lady Gaga', 'Katy Perry', 'Rihanna', 'Lil Kelv', '2', 0, 0),
(169, 'Was haben Kiefer Sutherland, Ashton Kutcher und Gisele Bündchen gemeinsam? ', 1, ' Sie betreiben eigene Weinlokale in Paris. ', ' Sie haben zwei verschieden farbige Augen. ', ' Sie haben Zwillingsgeschwister. ', ' Sie mögen keine Oliven.', '3', 0, 0),
(170, 'Was wird in Baden-Württemberg durch die sogenannte Zwei-Meter-Regel bestimmt?', 1, 'maximale Größe der Besucher der Stuttgarter Einkaufspassage', 'Radius um Hauseingänge, in dem kein Baum stehen darf', 'Entfernung zwischen Haustür und Briefkasten', 'minimale Breite von Waldwegen, die Radfahrer nutzen dürfen', '4', 0, 0),
(171, 'Was wird in Baden-Württemberg durch die sogenannte Zwei-Meter-Regel bestimmt?', 1, 'maximale Größe der Besucher der Stuttgarter Einkaufspassage', 'Radius um Hauseingänge, in dem kein Baum stehen darf', 'Entfernung zwischen Haustür und Briefkasten', 'minimale Breite von Waldwegen, die Radfahrer nutzen dürfen', '4', 0, 0),
(173, 'Die etwa 440.000 Einwohner zählende Stadt Iquitos in Peru ...?', 1, 'hat zwölf Bürgermeister, die sich monatlich abwechseln', 'ist nur mit dem Schiff oder dem Flugzeug erreichbar', 'ist die am höchsten und niedrigsten gelegene Stadt des Landes', 'verspricht jedem Bürger monatlich ein Gratis Fladenbrot', '2', 1, 0),
(174, 'Wodurch werden seit 2013 wenig befahrene, schmale Landstraßen in Deutschland sicherer gemacht?', 1, 'trapezförmige Markierungen über die gesamte Fahrbahnbreite', 'abwechselnd rote und gelbe Reflektoren an den Leitpfosten', 'gestrichelte, eingerückte Fahrbahnrandmarkierungen', 'reflektierende Bänder um die Bäume am Straßenrand', '3', 0, 0),
(175, 'Laut Oberlandesgericht darf ein Kunde den Vertrag mit einem Fitnessstudio vor Ablauf der Laufzeit kündigen, wenn ...?', 1, 'der Kunde berufsbedingt umzieht', 'die Vertragslaufzeit kürzer ist als sechs Monate', 'das Studio den Trainingsort innerhalb der Stadt verlegt', 'der Kunde sich langfristig verletzt', '3', 0, 0),
(172, 'Wenn bei einem Sprung in den Pool Wasser in die Nase gelangt, schmerzt es unmittelbar, weil ...?', 1, 'der Körper die Salzkonzentration ausgleichen will', 'es durch gleichzeitiges Ausatmen zu einer Rückkopplung kommt', 'die Nasennebenhöhlen sich zum Schutz verschließen', 'kleine Nasenhaare abgerissen wurden', '1', 0, 0),
(176, 'Die Analyse der Kiemenreusen von Riesenmantas soll zukünftig dabei helfen, …?', 1, 'den Fischfang nachhaltiger zu gestalten', 'das Verstopfen von Filtern und Sieben zu verhindern', 'Bergsteiger gegen die Höhenkrankheit zu immunisieren', 'Mikroplankton zu erforschen', '2', 1, 1),
(177, 'Wozu ist Omas Häkeldeckchen hilfreich?', 1, 'beim Polieren von Silber', 'bei der Verzierung von Kuchen', 'um das Überkochen von Milch zu verhindern', 'bei der Honigernte', '2', 1, 1),
(178, 'Wer Himbeeren oder Brombeeren für den späteren Verzehr einfrieren möchte, sollte sie am besten ...?', 1, 'auf einem Teller liegend einfrieren', 'kurz in Zuckerwasser blanchieren', 'mit Öl und Zitronensaft einsprühen', 'mit Salz bestreuen', '1', 0, 0),
(179, 'Sprenggelatine ...?', 1, 'wird zum Herstellen von Sülze benötigt', 'ist Bestandteil vieler Kosmetikprodukte', 'ist leistungsfähiger als Dynamit', 'ist ein Nebenprodukt von Wackelpudding', '3', 0, 0),
(180, 'Wer den Federsee in der Nähe des oberschwäbischen Bad Buchau besucht, ...?', 1, 'kann sein Echo 11 Mal hören', 'kann über die Wasseroberfläche laufen', 'steht in einem aktiven Vulkan', 'kann durch leichtes Hüpfen die Bäume wackeln lassen', '4', 2, 1),
(181, 'Der Begriff „Vernissage“ bezeichnete ursprünglich den ...?', 1, '\r\nvereinbarten Termin für die Abgabe einer Auftragsarbeit', 'frisch geschmiedeten Hufen eines Pferdes', 'geschätzten Wert eines Gemäldes durch einen Kunstkritiker', 'Tag, an dem das Gemälde mit Firnis überzogen wurde', '4', 1, 0),
(182, 'Zu welcher Erfindung inspirierten „Die Irrfahrten des Odysseus“ den Berliner Apotheker Maximilian Negwer?', 1, 'Tampons', 'Reisetabletten', 'Heftpflaster', 'Ohrstöpsel', '4', 2, 1),
(183, 'Die Stadt Amsterdam ...?', 1, 'verschickte kostenlose Recycling-Kaffeebecher an alle Bürger', 'hat 256 Brücken', 'vergibt zinslose Kredite zum Fahrradkauf', 'lässt Schuhsohlen aus alten Kaugummis von der Straße machen', '4', 1, 1),
(184, 'Welches Tier gilt als Symbol für die Demokratische Partei in den Vereinigten Staaten?', 1, 'Bulle', 'Elefant', 'Esel', 'Adler', '3', 0, 0),
(185, 'Ein Fahrradweg darf nur dann in beide Richtungen befahren werden, wenn ...?', 1, '\r\ner nur an einer Seite der Straße verläuft', 'dies ausdrücklich mit einem Zusatzschild erlaubt ist', 'in näherer Umgebung keine Überquerung der Straße möglich ist', 'er mindestens 2,5m breit ist', '2', 1, 1),
(186, 'Welcher Umgang mit der Avocado birgt ein ungeahntes Gesundheitsrisiko?', 1, 'das Fruchtfleisch mit einem Silberlöffel herausnehmen', 'Mehr als 3 Stück am Tag zu essen', 'den Kern in die nicht verzehrte Hälfte legen und kühl lagern', 'anschneiden, ohne die Schale gründlich zu waschen', '4', 0, 0),
(187, 'Der Amerikaner Strom Thurmond gelangte 1957 zu internationaler Bekanntheit, weil er ...?', 1, 'New Yorks gesamten Vorrat an Erdnussbutter aufkaufte ', 'sämtliche Filmrollen aus dem Archiv Hollywoods raubte ', ' im Senat 24 Stunden lang über Gesetze und Kuchenrezepte sprach ', 'Wasser aus öffentlichen Springbrunnen verkaufte', '3', 1, 0),
(188, 'Was darf Speiseeis enthalten, wenn auf der Verpackung \"Eis\" statt \"Eiscreme\" steht?', 1, 'pflanzliche Fette ', 'zehn Prozent Eigelb ', 'Fruktosesirup', '0.1% Bullenurin', '1', 0, 0),
(189, 'Was gilt laut § 138 des Bürgerlichen Gesetzbuches als Wucher?', 1, '\"Geschäft, das den Käuferinteressen außerordentlich schadet\" ', '\"Rechtsgeschäft, das gegen die guten Sitten verstößt\" ', '\"Warenangebot, bei dem der Preis mindestens doppelt so hoch wie bei anderen Anbietern ist.\"', '\"Vertrag, bei dem sich die Konditionen nach Abschluss verändern\" ', '2', 0, 0),
(190, 'Warum empfehlen Forscher Studenten, bei Prüfungen aufrecht zu sitzen?', 1, 'So stehen Auge und Tisch in einem perfekten Winkel zueinander. ', 'Es wird mehr Adrenalin freigesetzt. ', 'Bei schlaffer Haltung arbeitet das Gehirn weniger gut. ', 'Die Pomuskeln werden besser durchblutet und machen das sitzen angenehmer und schmerzfreier.', '3', 2, 0),
(191, 'Essig auf einem Stück Toastbrot ...?', 1, 'verhindert, dass das Brot im Brotkasten schimmelt ', 'sorgt für streifenfreie Spiegelflächen ', 'entfernt schlechte Gerüche aus dem Mülleimer ', 'verschreckt Mücken', '3', 0, 0),
(192, 'Wie sollten moderne Jeans aus \"Coated Denim\" laut Herstellern am besten gereinigt werden?', 1, 'mit einer Nagelbürste schrubben und dabei heiß föhnen ', 'mit einem feuchten, antistatischen Staubtuch abreiben ', 'zehn Minuten in kaltes Wasser legen ', 'heiß waschen aber nicht in den trockner packen', '3', 111, 0),
(193, ' Damit den vielen Anglern an Utahs Seen möglichst nicht die Fische ausgehen, werden regelmäßig …?', 1, 'tausende Fische aus Flugzeugen in die Seen geworfen ', 'Spaziergänger mit kostenlosem Fischfutter ausgestattet ', 'Fischotter und Kormorane massenhaft umgesiedelt ', 'Mastfutterrestbestände in die Seen gekippt', '1', 0, 0),
(194, ' Überraschenderweise verfügen Ameisen über …?', 1, 'Nippel', 'Selbstkontrolle ', 'Humor', 'Tränendrüsen', '2', 0, 0),
(195, 'Welche Entdeckung wurde Anfang 2018 von einem Heimatforscher veröffentlicht?', 1, 'Köln und Aachen waren durch einen römischen Tunnel verbunden. ', '80 Meter Berliner Mauer wurden beim Abriss übersehen. ', 'Lübeck liegt mitten auf einem Keltischen Massengrab', 'Der Stuttgarter Hauptbahnhof steht auf einer alten Markthalle. ', '2', 0, 0),
(196, 'Warum fallen überreife Äpfel vom Baum?', 1, 'Der Apfel wird zu schwer für den Ast. ', 'Der Baum bildet Sollbruchstellen, um den Apfel fallen zu lassen. ', 'Der Stiel verfault und verrottet mit dem Apfel. ', 'Kleine Käfer und Ameisen fressen den Stiel ab.', '2', 0, 0),
(197, 'In einem Flockierstuhl werden ...?', 1, 'minderwertige Baumwollfäden aufgesponnen ', 'Autositze mit Schaumstoff gefüllt ', 'Haferflocken in ihre flache Form gewalzt ', 'Eiscremepackungen befüllt', '3', 0, 0),
(198, 'Wenn Franzosen von einem \"Holzmaul\" sprechen, ...? ', 1, 'haben wir einen \"Frosch im Hals\" ', 'beißen wir in den \"sauren Apfel\" ', 'haben wir einen \"Kater\" ', 'redet bei uns jemand wie ein \"Wasserfall\"', '3', 0, 0),
(199, 'Welches sind die am dichtesten beieinanderliegenden Hauptstädte Europas?', 1, 'Wien und Bratislava ', 'Bern und Vaduz ', 'San Marino und Rom ', 'London und Brüssel', '1', 0, 0),
(200, 'Wer herrscht seit anbeginn der Zeit über die Wüste?', 1, 'Der Ebbenverdränger', 'Der Küstenerweiterer', 'Der Dammzerschmetterer', 'Der Dünenerschaffer', '2', 1, 0),
(201, 'Was hatten Wolfgang Amadeus Mozart, Katharina die Große und George Washington gemeinsam?', 1, 'Sie erfuhren nie, dass der Mensch im Heißluftballon fliegen kann.', 'Sie hatten keine Chance, in den Genuss der Pellkartoffel zu kommen.', 'Sie wussten nicht, dass Dinosaurier auf der Erde gelebt haben.', 'Sie haben nie gewusst, dass es Neandertaler gab', '3', 0, 0),
(202, 'Weshalb wird ein Teil der 28. Straße in New York auch als „Tin Pan Alley“ bezeichnet?', 1, 'Um 1900 befand sich hier ein Zentrum der Musikindustrie.', 'Vor der Gründung der Stadt wurde hier nach Gold geschürft.', 'In den 1930er-Jahren gab es hier die meisten Restaurants der Stadt.', 'Früher war dort der weltgrößte Hersteller für Pfannen ansässig', '1', 0, 0),
(203, 'Das bei der Reifung von Sherry angewandte Solera-System führt dazu, dass die so hergestellten Getränke ...?', 1, 'nach der Abfüllung im Freien zwischengelagert werden müssen', 'aus vielen verschiedenen Altersstufen bestehen', 'mehr Alkohol enthalten als vor der Reifung\r\n', 'eine besonders lange Haltbarkeit haben', '2', 0, 0),
(204, 'Womit können Flusen von der Kleidung entfernt werden, wenn gerade keine Fusselrolle zur Hand ist?', 1, 'Kamm und feuchter Teebeutel', 'Schnürsenkel und Kerzenwachs', 'Papiertuch und Haarspray', 'Honig und Kleiderbügel', '3', 1, 1),
(205, 'Wer Hackfleisch vor dem Einfrieren gleichmäßig portionieren will, greift zu Gefrierbeutel und ...?\r\n', 1, 'Schwamm\r\n', 'Holzstäbchen', 'Sprudelwasser', 'Socken', '2', 0, 0),
(206, 'Warum ist der Sonnenuntergang auf dem Mars im Gegensatz zu dem auf der Erde bläulich?', 1, 'Blau wird in der wolkenlosen Atmosphäre nicht herausgefiltert.', 'Durch Staubpartikel ist die Lichtstreuung auf dem Mars anders.', 'Die Sonne trifft die Planeten in unterschiedlichen Winkeln.', 'Der Blaue Planet reflektiert das Sonnenlicht und färbt die Marsatmosphäre', '2', 1, 1),
(207, 'Was ist das Besondere am Weberknecht „Metagryne bicolumnata“?\r\n', 1, 'Sein Körper sieht aus wie ein Hundekopf.\r\n', 'Er kann traben wie ein Pferd.\r\n', 'Sein Warnruf erreicht bis zu 100 Dezibel.\r\n', 'Er wird mehrere Jahre alt', '1', 2, 0),
(208, 'Warum ist die kleine Ostseeinsel Riems größtenteils Sperrgebiet?', 1, 'Sie ist Brutstätte für vom Aussterben bedrohte Robben.', 'Europas größtes Unterseekabel kommt auf der Insel an.', 'Wissenschaftler erforschen dort gefährliche Viren und Bakterien.', 'Ein Schiffsunglück 2016 verunreinigte die Insel mit Öl.', '3', 0, 0),
(209, 'Wer empfiehlt die FSK-Methode?', 1, 'Bundesbank zur Identifizierung von Falschgeld', 'Ärztekammer zum Senken des Blutzuckerspiegels', 'Finanzamt zum Errechnen des Kinderfreibetrags', 'Bundespolizei um sich vor Diebstahl zu schützen', '1', 3, 0),
(210, 'Katzenallergiker sollten sich bewusst sein, dass sie auch ...?', 1, 'den Kontakt zu Hasen und Meerschweinchen meiden sollten', 'bei Raubkatzen im Zoo einen Allergieanfall erleiden können', 'beim Verzehr von Kreuzkümmel ähnliche Symptome spüren können', 'gegen Federn von Kormoranen alergisch reagieren', '2', 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `fStats`
--

CREATE TABLE `fStats` (
  `BenutzerID` int(5) NOT NULL,
  `FrageID` int(5) NOT NULL,
  `processed` int(10) NOT NULL,
  `correct` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `fStats`
--

INSERT INTO `fStats` (`BenutzerID`, `FrageID`, `processed`, `correct`) VALUES
(5, 2, 1, 0),
(5, 3, 1, 1),
(5, 4, 1, 1),
(5, 5, 1, 0),
(5, 6, 1, 0),
(5, 9, 1, 0),
(5, 14, 1, 0),
(5, 17, 1, 0),
(5, 19, 1, 0),
(5, 21, 1, 1),
(5, 22, 1, 0),
(5, 32, 1, 0),
(5, 33, 1, 0),
(5, 35, 1, 0),
(5, 48, 1, 0),
(5, 49, 1, 0),
(5, 55, 1, 0),
(5, 57, 1, 1),
(5, 58, 1, 0),
(5, 62, 1, 0),
(5, 64, 1, 0),
(5, 69, 1, 1),
(5, 76, 1, 0),
(5, 81, 1, 0),
(5, 85, 1, 0),
(5, 87, 1, 0),
(5, 88, 1, 0),
(5, 89, 1, 0),
(5, 93, 1, 0),
(5, 94, 1, 0),
(5, 100, 1, 0),
(5, 105, 1, 0),
(5, 114, 1, 0),
(5, 115, 1, 0),
(5, 119, 1, 0),
(5, 123, 1, 0),
(5, 124, 1, 0),
(5, 129, 1, 0),
(5, 132, 1, 1),
(5, 133, 1, 0),
(5, 134, 1, 0),
(5, 136, 1, 1),
(5, 137, 1, 0),
(5, 146, 1, 1),
(5, 149, 1, 1),
(5, 151, 1, 0),
(5, 153, 1, 0),
(5, 154, 1, 0),
(5, 156, 1, 0),
(5, 157, 1, 0),
(5, 165, 1, 0),
(5, 166, 1, 1),
(5, 173, 1, 0),
(5, 176, 1, 1),
(5, 177, 1, 1),
(5, 180, 1, 1),
(5, 181, 1, 0),
(5, 182, 1, 1),
(5, 183, 1, 1),
(5, 187, 1, 0),
(5, 190, 1, 0),
(5, 200, 1, 0),
(5, 204, 1, 1),
(5, 206, 1, 1),
(5, 207, 1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kategorie`
--

CREATE TABLE `kategorie` (
  `Name` varchar(99) NOT NULL,
  `Zahl` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `kategorie`
--

INSERT INTO `kategorie` (`Name`, `Zahl`) VALUES
('Standard', 1),
('Wissenschaft', 2),
('Politik', 3),
('Geschichte', 4),
('Sport', 5),
('Unnützes Wissen', 6),
('Technik', 7);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `statistiken`
--

CREATE TABLE `statistiken` (
  `BenutzerID` int(5) NOT NULL,
  `BFragen` int(10) NOT NULL,
  `RFragen` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `statistiken`
--

INSERT INTO `statistiken` (`BenutzerID`, `BFragen`, `RFragen`) VALUES
(1, 0, 0),
(5, 25, 11);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  ADD PRIMARY KEY (`BenutzerID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indizes für die Tabelle `fragen`
--
ALTER TABLE `fragen`
  ADD PRIMARY KEY (`FrageID`);

--
-- Indizes für die Tabelle `fStats`
--
ALTER TABLE `fStats`
  ADD PRIMARY KEY (`BenutzerID`,`FrageID`);

--
-- Indizes für die Tabelle `kategorie`
--
ALTER TABLE `kategorie`
  ADD PRIMARY KEY (`Zahl`);

--
-- Indizes für die Tabelle `statistiken`
--
ALTER TABLE `statistiken`
  ADD PRIMARY KEY (`BenutzerID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  MODIFY `BenutzerID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `fragen`
--
ALTER TABLE `fragen`
  MODIFY `FrageID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- AUTO_INCREMENT für Tabelle `kategorie`
--
ALTER TABLE `kategorie`
  MODIFY `Zahl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT für Tabelle `statistiken`
--
ALTER TABLE `statistiken`
  MODIFY `BenutzerID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
